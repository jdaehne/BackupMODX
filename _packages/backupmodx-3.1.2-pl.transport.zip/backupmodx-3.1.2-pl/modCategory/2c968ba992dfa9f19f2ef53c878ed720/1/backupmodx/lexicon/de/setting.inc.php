<?php
/**
 * Setting Lexicon Entries for BackupMODX
 *
 * @package backupmodx
 * @subpackage lexicon
 */
$_lang['area_cron'] = 'Cron';
$_lang['setting_backupmodx.cronDatabase'] = 'Backup Datenbank';
$_lang['setting_backupmodx.cronDatabase_desc'] = 'Datenbank bei Cron-Backup berücksichtigen.';
$_lang['setting_backupmodx.cronEnable'] = 'Cron aktivieren';
$_lang['setting_backupmodx.cronEnable_desc'] = 'Cron-Backup aktivieren oder deaktivieren.';
$_lang['setting_backupmodx.cronFiles'] = 'Backup Dateien';
$_lang['setting_backupmodx.cronFiles_desc'] = 'Dateien bei Cron-Backup berücksichtigen.';
$_lang['setting_backupmodx.cronKey'] = 'Cron Sicherheitsschlüssel';
$_lang['setting_backupmodx.cronKey_desc'] = 'Sicherheitsschlüssel für Cron gesteuerte Backups. Kann eine beliebige Zeichenfolge sein.';
$_lang['setting_backupmodx.cronMaxDatabase'] = 'Max Datenbanken';
$_lang['setting_backupmodx.cronMaxDatabase_desc'] = 'Maximale Anzahl von Datenbanken die als Backup vorgehalten werden sollen.';
$_lang['setting_backupmodx.cronMaxFiles'] = 'Max Dateien';
$_lang['setting_backupmodx.cronMaxFiles_desc'] = 'Maximale Anzahl von Datei-Archiven die als Backup vorgehalten werden sollen.';
$_lang['setting_backupmodx.cronNote'] = 'Notiz';
$_lang['setting_backupmodx.cronNote_desc'] = 'Optionale Notiz zum Cron-Backup als Text-Datei.';
$_lang['setting_backupmodx.debug'] = 'Debug';
$_lang['setting_backupmodx.debug_desc'] = 'Debug-Informationen im MODX Fehlerprotokoll ausgeben.';
$_lang['setting_backupmodx.excludeFiles'] = 'Dateien ausschließen';
$_lang['setting_backupmodx.excludeFiles_desc'] = 'Kommaseparierte Liste von Dateien, die von der Sicherung ausgeschlossen werden sollen. Reguläre Ausdrücke sind möglich. Beispiel: \..* für Dateinamen, die mit einem Punkt beginnen.';
$_lang['setting_backupmodx.excludeFolders'] = 'Verzeichnisse ausschließen';
$_lang['setting_backupmodx.excludeFolders_desc'] = 'Kommaseparierte Liste von Ordnern, die von der Sicherung ausgeschlossen werden sollen. Pfadplatzhalter sind verfügbar. Beispiel: {Assets_path}uploads/';
$_lang['setting_backupmodx.groups'] = 'Gruppen';
$_lang['setting_backupmodx.groups_desc'] = 'Kommagetrennte Liste der Namen von Benutzergruppen, die Zugriff auf das Widget haben sollen.';
$_lang['setting_backupmodx.targetPath'] = 'Backup Ziel Pfad';
$_lang['setting_backupmodx.targetPath_desc'] = 'Pfad zum Speichern des Backups. Pfad-Platzhalter sind möglich. Beispiel: {core_path}backup/';
$_lang['setting_backupmodx.timelimit'] = 'Backup Zeitlimit';
$_lang['setting_backupmodx.timelimit_desc'] = 'Zeitlimit für das Backup in Sekunden.';
